#include <iostream>

class document
{
	private:
		char* titre;
		char* mot-cle[10];
	public:
		document(char*);
		~document();
}