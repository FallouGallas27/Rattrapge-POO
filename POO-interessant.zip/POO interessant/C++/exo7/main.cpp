#include <iostream>
#include"pile.cpp"
using namespace std;

void *f(int i)
{
   return((void*)i);
}

int main()
{
    Pile P;
    if(P.estVide())
        cout<<"la pile est vide"<<endl;
    else
        cout<<"la pile n'est pas vide"<<endl;
    P.empiler(f(1));
    P.empiler(f(3));
    P.empiler(f(8));
    P.empiler(f(2));
    cout<<(int)P.sommet()<<endl<<endl;
    cout<<"la taille de la pile est:"<<P.longueur_pile();
    cout<<"\nAffichage de la pile\n";
    P.afficher_pile();
    P.depiler();
    cout<<"Apres depilement"<<endl;
    P.afficher_pile();
    return 0;
}
