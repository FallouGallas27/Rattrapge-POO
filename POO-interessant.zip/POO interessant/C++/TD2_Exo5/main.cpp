#include "pile.h"

void afficher(pile p)
{
	cout<<"\n Voici la pile\n"<<endl;
	int x;
	for(int i=0; i<p.taille_p(); i++)
	{	
		cout<<p.sommet(); 
		cout<<" ";
		//p.depiler();
		p>>x;
	}
	cout<<endl;
}
int main()
{
	pile p(10);
	if(p.est_vide())
		cout<<"\n La pile est vide\n";
	else
		cout<<"\n La pile n est pas vide\n";
	p.empiler(2);
	afficher(p);
	p.empiler(3);
	afficher(p);
	p.empiler(4);
	afficher(p);
	p.empiler(5);
	afficher(p);
	p.empiler(6);
	afficher(p);
	//p.depiler();
	//afficher(p);
	//p<<1<<2<<3<<4<<5;
	//p<<1<<2;
	//p<<1<<2<<3<<4<<5<<6<<7<<8;
	afficher(p);
	return 0;

}