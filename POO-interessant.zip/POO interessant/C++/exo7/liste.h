#ifndef LISTE_H_INCLUDED
#define LISTE_H_INCLUDED

struct Place{
    void* element;
    Place* suiv;
};
class Liste{
private:
    int m_longueur;
    Place* m_premier;
    Place* m_courant;
public:
    Liste();
    ~Liste();
    Liste(Liste&);
    Liste& operator=(Liste& );
    void ajouter(int, void*);
    void* supprimer(int);
    void* ieme(int );
    int longueur(){return (m_longueur);};
    void init(){ m_courant=m_premier->suiv;};
    int existe(){ return (m_courant!=0);};
    void* prochain(){
        void* temp=m_courant->element;
        m_courant=m_courant->suiv;
        return(temp);
    };
};

#endif // LISTE_H_INCLUDED
