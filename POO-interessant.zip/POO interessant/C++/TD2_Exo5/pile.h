#include<iostream>

using namespace std;

class pile
{
	private:
		int max;
		int taille;
		int *tab;
	public:
		pile(int); // Constructeur
		~pile(); // Destructeur
		void empiler(int);
		void depiler();
		//pile& operator<<(int);
		//pile& operator>>(int x);
		int sommet();
		bool est_vide();
		int taille_p();
};