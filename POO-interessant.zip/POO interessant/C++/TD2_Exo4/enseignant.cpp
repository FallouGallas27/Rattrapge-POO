#include"enseignant.h"

using namespace std;

enseignant::enseignant(char* n, char* p, char* d)
{
	//cout<<"\n Appel du constructeur \n";
	cout<<"***************";
	nom=new char[strlen(n)+1];
	strcpy(nom, n);
	prenom=new char[strlen(p)+1];
	strcpy(prenom, p);
	diplome=new char[strlen(d)+1];
	strcpy(diplome, d);
	for(int i=0; i<5; i++)
		matiere[i]=NULL;
	cout<<"\n Appel du constructeur \n";
}
/*enseignant::enseignant(enseignant& ens)
{
	cout<<"\n Appel du constructeur de recopie\n";
	strcpy(prenom, ens.prenom);
	strcpy(nom, ens.nom);
	strcpy(diplome, ens.diplome);
	/*int i=0;
	while()
	{	
		strcpy(matiere[i], ens.matiere[i]);
		i++;
	}
}*/
enseignant::~enseignant()
{
	cout<<"\n Appel du destructeur\n";
	if(prenom)
		delete prenom;
	if(nom)
		delete nom;
	if(diplome)
		delete diplome;
	for(int i=0; i<10; i++)
		if(matiere[i])
			delete matiere[i];
}
char* enseignant::get_nom()
{
	return nom;
}
char* enseignant::get_prenom()
{
	return prenom;
}
char* enseignant::get_diplome()
{
	return diplome;
}
/*void enseignant::ajout_matiere(char* m)
{
	int i=0;
	while(i<5&&matiere[i]!=NULL&&strcmp(matiere[i], m)!=0)
		i++;
	if(i<5)
	{
		if(matiere[i]==NULL)
		{
			matiere[i]=new char[strlen(m)+1];
			strcpy(matiere[i], m);
		}
		else if(strcmp(matiere[i], m)==0)
			cout<<"\n Ce professeur enseigne deja cette matiere !\n";
	}
	else
		cout<<"\n Ce professeur enseigne deja dix matiere !\n";
}*/
void enseignant::afficher()
{
	cout<<endl;
	cout<<"\n   Prenom : "<<prenom;
	cout<<"\n   Nom    : "<<nom;
	cout<<"\n  Diplome : "<<diplome<<endl;
	int i=0;
	while((i<5)&&(matiere[i]!=NULL))
	{
		cout<<" Matiere["<<i<<"] : "<<matiere[i]<<endl;
		i++;
	}
}
enseignant& enseignant::operator<<(char* m)
{
	int i=0;
	while(i<5&&matiere[i]!=NULL&&strcmp(matiere[i], m)!=0)
		i++;
	if(i<5)
	{
		if(matiere[i]==NULL)
		{
			matiere[i]=new char[strlen(m)+1];
			strcpy(matiere[i], m);
			return (*this);
		}
		else if(strcmp(matiere[i], m)==0)
		{
			cout<<"\n Ce professeur enseigne deja cette matiere !\n";
			return (*this);
		}
	}
	else
	{	cout<<"\n Ce professeur enseigne deja 5 matiere !\n";
		return (*this);
	}
}
enseignant& enseignant::operator>>(char* m)
{
	int i=0;
	while((i<5)&&strcmp(matiere[i], m)!=1)
		i++;
	if(i>=5)
	{
		cout<<"\n Ce prof n enseigne pas cette matiere !"<<endl;
		return (*this);
	}
	else
	{
		for(int j=i; j<4; j++)
			strcpy(matiere[j], matiere[j+1]);
	}
	return (*this);
}
