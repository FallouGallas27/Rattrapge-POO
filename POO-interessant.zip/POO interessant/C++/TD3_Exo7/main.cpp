#include "Liste.h"
#include "pile.h"

int main()
{
	pile P;
	int x1=1, x2=2, x3=3, x4=4;
	void* tab1; tab2, tab3, tab4;
	tab1=&x1;
	tab2=&x2;
	tab3=&x3;
	tab4=&x4;
	
	empiler(tab1);
	empiler(tab2);
	empiler(tab3);
	empiler(tab4);

	bool b=P.est_vide();	
	if(b)
		cout<<"\n La pile est vide\n";
	else
		cout<<"\n La pile n est pas vide\n";
	cout<<" Longueur (pile) = "<<P.get_longueur();
	
	void* s=P.get_sommet();
	void* sommet=&s;
	cout<<"\n Sommet (pile) = "<<sommet;
	return 0;
}
