#include"Exo1.h"
using namespace std;
int main()
{
	Matrice *m=NULL, *P=NULL, *T=NULL, *M=NULL;
	m=creer_matrice(2, 3);
	m=saisir_matrice(m);
	M=creer_matrice(3, 2);
	M=saisir_matrice(M);
	afficher_matrice(m);
	cout<<endl;
	afficher_matrice(M);
	cout<<endl;
	T=transposee_matrice(m);
	cout<<"Matrice transposee : "<<endl;
	afficher_matrice(T);
	P=matrice_produit(m,M);
	cout<<"Matrice produit : "<<endl;
	afficher_matrice(P);
	detruire_matrice(m);
	detruire_matrice(P);
	detruire_matrice(T);
	detruire_matrice(M);
	return 0;
}