#include"Lettre.h"
using namespace std;

Lettre ::Lettre(double p, string m, string adrexp,string adrdest,string f) :Courier(p,m,adrexp,adrdest)
{
	format=f;
    cout<<"\nAppel du constructeur de la classe Lettre\n";
}
Lettre ::~Lettre()
{
    cout<<"Appel du destructeur de la classe Lettre\n";

}

double Lettre ::PrixTimbre()
{
	double montant=0.0;
	if(mode=="normal")
    {
        if(format=="A4")
            montant=250;
        else
            montant=350;
        montant+=1.0*poids/1000;
        return montant;
    }
    else
    {
        if(format=="A4")
            montant=250;
        else
            montant=350;
        montant+=2.0*poids/1000;
        return montant;
    }
    return 0;

}

/*void Lettre:: afficher(ostream &out) const
{
    out<<"Ceci est une lettre\n";
    Courier::afficher(out);
    out<<"Format : "<<format<<endl;
}*/
void Lettre:: afficher() const
{
    cout<<"Ceci est une lettre\n";
    Courier::afficher();
    cout<<"Format : "<<format<<endl;
}















