

class file:public liste
{
	private:

	public:
		liste();
		~liste();
		void enfiler(int);
		void defiler();
		int get_sommet();
		bool est_vide();
		int get_longueur();
}