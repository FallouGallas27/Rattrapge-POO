#include "animal.h"
#include "mammifere.h"
#include <iostream>
using namespace std;

mammifere::mammifere(string n):animal(n)
{
	cout<<"\n Appel du constructeur de mammifere\n";
}

mammifere::~mammifere()
{
	cout<<"\n Appel du destructeur de mammifere\n";
}
