#ifndef BASE_H
#define BASE_H

#include <iostream>
#include <string>

class base 
{
	public:
		virtual void afficher()=0;
		virtual int clef()=0;
};

#endif 