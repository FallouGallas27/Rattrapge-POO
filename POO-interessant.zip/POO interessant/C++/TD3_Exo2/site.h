#include "document.h"

class site
{
	private:
		document* liste;
	public:
		site();
		site(site&);
		~site();
		void ajouter(document);
		void supprimer(document);
		bool rechercher(char* m_cle);
},