#ifndef PILE_H_INCLUDED
#define PILE_H_INCLUDED

class Pile:private Liste{
 public:
     Pile();
     ~Pile();
     void empiler(void* );
     void* sommet();
     void* depiler();
     bool estVide();
     int longueur_pile();
     void afficher_pile();
};

#endif // PILE_H_INCLUDED
