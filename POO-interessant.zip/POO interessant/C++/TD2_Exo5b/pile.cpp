#include"pile.h"
using namespace std;

pile::pile()
{
	sommet=NULL;
	cout<<"\n Appel du constructeur par defaut \n";
}

pile::~pile()
{
	if(sommet)
	{
		while(sommet->suiv)
		{
			delete sommet->suiv;
			sommet=sommet->suiv;
		}
	}
	cout<<"\n Appel du destructeur \n";		
}

pile::pile(pile& P)	
{
	pile p;
	while(!P.est_vide())
	{
		int x=P.depiler();
		p.empiler(x);
	}
	while(!p.est_vide())
	{
		int y=p.depiler();
		empiler(y);
		P.empiler(y);
	}
	cout<<"\n Appel du constructeur de recopie\n";
}

void pile::empiler(int x)	
{
	pPile elt;
	elt=new pile_elt;
	elt->val=x;
	elt->suiv=sommet;
	sommet=elt;
}
    
int pile::depiler()  
{ 
	if(est_vide()) 
	{	cout<<"\n La pile est vide! \n"; 
		//exit(-1);
		return -1;
	}
	else
	{
		pPile p;
		int x=get_sommet();
		p=sommet;
		sommet=sommet->suiv;
		delete p;
		return x;
	}
}
 
int pile::get_sommet()const        
{
 	return (sommet->val);
}
 
bool pile::est_vide()const	
{
	if(sommet==NULL)
		return true;
	else
		return false;	     
}



















/*pile& pile::operator<<(int)
{
	pPile elt;
	elt=new pile_elt;
	elt->val=x;
	elt->suiv=sommet;
	sommet=elt;
	return (*this);
}

pile& pile::operator>>()
{
	if(est_vide()) 
	{	cout<<"\n La pile est vide! \n"; 
		//exit(-1);
		return -1;
	}
	else
	{
		pPile p;
		int x=get_sommet();
		p=sommet;
		sommet=sommet->suiv;
		delete p;
		return x;
	}
}*/	
//pile& pile::operator=(pile p)






