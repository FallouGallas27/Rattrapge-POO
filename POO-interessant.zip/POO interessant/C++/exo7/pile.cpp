#include<iostream>
#include"liste.cpp"
#include"Pile.h"
using namespace std;
Pile::Pile():Liste(){
    cout<<"appel du constructeur pile"<<endl;
};
Pile::~Pile(){
    cout<<"Appel du destructeur"<<endl;
    cout<<this;
};
void Pile::empiler(void* pe){
    Liste::ajouter(longueur(),pe);
};
void* Pile::sommet(){
    return Liste::ieme(longueur_pile());
};
void* Pile::depiler(){
   return Liste::supprimer(1);
};
bool Pile::estVide(){
    if(Liste::longueur()==0)
        return true;
    return false;
};
int Pile::longueur_pile(){
    return (Liste::longueur());
};

void Pile::afficher_pile(){
    cout<<(int)sommet()<<endl;
    Liste::init();
    while(Liste::existe()){
        cout<<(int)prochain()<<endl;
    }
}

