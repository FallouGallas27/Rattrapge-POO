#include<iostream>
#include<cstring>
class enseignant
{
	private:
		char* nom;
		char* prenom;
		char* diplome;
		char* matiere[5];
	public:
	enseignant(char*, char*, char*);
	//enseignant(enseignant&); //Constructeur de recopie
	~enseignant();
	char* get_nom();
	char* get_prenom();
	char* get_diplome();
	//void ajout_matiere(char*);
	enseignant& operator<<(char*);
	enseignant& operator>>(char*); 
	void afficher();
	
	
};