#include "animal.h"
#include "mammifere.h"
#include "oiseau.h"
#include "chat.h"
#include "souris.h"
#include "canari.h"
using namespace std;

int main()
{
	chat S("Sylvetre"), T("Tom");
	souris s("Jerry");
	canari c("Titi");

	animal *a[4]; 
	
	a[0]=&S;
	a[1]=&T;
    a[2]=&s;
    a[3]=&c;
    for(int i=0; i<4; i++)
    	a[i]->exprime_toi();
	return 0;
}