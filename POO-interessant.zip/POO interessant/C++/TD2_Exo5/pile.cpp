#include "pile.h"
using namespace std;

pile::pile(int N)
{
	cout<<" \nAppel du constructeur \n";
	max=N;
	taille=0;
	//tab=NULL;
}
pile::~pile()
{
	if(tab)
		delete (tab);
}
void pile::empiler(int x)
{
	if((*this).est_vide())
	{	
		taille=1; 
		tab=new int[1];
		tab[0]=x;
	}
	else
	{ 
		taille++;
		//tab=new int[taille];	
		tab[taille-1]=x;
		//taille++;
	}
}

void pile::depiler()
{
	if(est_vide())
	{
		cout<<"\n La pile est vide\n";
		//exit(-1);
	}
	else
	{
		//int x=tab[taille-1];
		taille--;
		//return x;
	}
}
/*pile& pile::operator<<(int x)
{
	/*if((*this).est_vide())
	{	
		taille=1; 
		tab=new int[1];
		tab[0]=x;
		return (*this);
	}
	else
	{
		taille++;
		//tab=new int[taille];	
		tab[taille-1]=x;
		//taille++;
		return (*this);
	}
	tab[taille]=x;
	taille++;
	return (*this);
}*/
pile& pile::operator>>(int x)
{
	if(est_vide())
	{
		cout<<"\n La pile est vide\n";
		exit(-1);
	}
	else
	{
		x=tab[taille-1];
		taille--;
		//return x;
		return (*this);
	}
}
int pile::sommet()
{
	return tab[taille-1];
}
bool pile::est_vide()
{
	if(taille==0)
		return true;
	else
		return false;
}
int pile::taille_p()
{
	return taille;
}
