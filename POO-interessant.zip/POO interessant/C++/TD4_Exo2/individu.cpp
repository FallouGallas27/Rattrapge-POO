#include "individu.h"

individu::individu(int i, string n, string p)
{
	id=i;
	nom=n;
	prenom=p;
	cout<<"\n Appel du constructeur de individu\n";
}

individu::~individu()
{
	cout<<"\n Appel du destructeur de individu\n";
}
void individu::afficher()
{
	cout<<"\n ---------- Affichage individu ---------- \n";
	cout<<"\n Identifiant : "<<id<<endl;
	cout<<"\n Nom : "<<nom<<endl;
	cout<<"\n Prenom : "<<prenom<<endl;
	cout<<endl;
}
int individu::clef()
{
	return id;
}