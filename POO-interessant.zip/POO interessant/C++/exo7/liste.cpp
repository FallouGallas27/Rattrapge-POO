#include<iostream>
#include"Liste.h"

using namespace std;

Liste::Liste(){
        m_premier=NULL;
        m_courant=NULL;
        m_longueur=0;
};

 Liste::~Liste(){
    m_courant=m_premier;
    while(m_courant!=NULL){
        Place *del = m_courant;
        m_courant=m_courant->suiv;
        delete(del);
    }
}
Liste& Liste::operator=(Liste& l){
    if(this == &l)
         return (*this);
    else{
        m_courant=m_premier;
        while(m_courant!=NULL){
        Place *sup= m_courant;
        m_courant=m_courant->suiv;
        delete(sup);
    }
    m_premier=l.m_premier;
    m_courant= m_premier;
    while(m_courant!=NULL){
        m_courant->element=l.m_courant->element;
        m_courant=m_courant->suiv;
    }
    return(*this);
    }

}

void Liste::ajouter(int i, void* pe){
    int j;
    Place* nouveau=new Place;
    nouveau->element=pe;
    nouveau->suiv=NULL;
    if(m_premier==NULL)
        m_premier=nouveau;
    else{
        m_courant=m_premier;
        for(j=1;j<i-1;j++)
            m_courant=m_courant->suiv;
        nouveau->suiv=m_courant->suiv;
        m_courant->suiv=nouveau;
    }
    m_longueur++;
}
void* Liste::supprimer(int i){
    if(i==0){
        Place* tete;
        tete=m_premier;
        m_premier=m_premier->suiv;
        delete tete;
        m_longueur--;
    }
    else{
         int j;
         Place *courant,*prec;
         courant=m_premier;
         for(j=0;j<i;j++){
             prec=courant;
             courant=courant->suiv;
   }
    prec->suiv=courant->suiv;
    return courant;
    m_longueur--;
    }
}
 void* Liste::ieme(int i){
    m_courant=m_premier;
    int j=1;
    while(j<i){
        m_courant=m_courant->suiv;
        j++;
    }
    return m_courant->element;
};

