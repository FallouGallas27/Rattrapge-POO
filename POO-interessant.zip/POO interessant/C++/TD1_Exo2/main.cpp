#include "complexe.h"
using namespace std;
int main()
{
	Complexe A(1, 2), B(3, 5);
	cout<<"\n\n Nous travaillons avec les complexes A=1+2i et B=3+5i\n";
	cout<<"\nLa partie reelle de A est : "<<A.reelle()<<endl;
	cout<<"La partie imaginaire de A est "<<A.imaginaire()<<endl;
	cout<<"\n\nVoici B\n";
	cout<<B;
	//B.afficher();
	cout<<endl;
	
	// Avant la surdéfinitions des opérateurs + et *
/*   Complexe c1, c2;
	c1=A.ajouter(B);
	cout<<"\n\nVoici c1=A+B\n";
	c1.afficher();
	cout<<endl;
	c2=A.multiplier(B);
	cout<<"\n\nVoici c2=A*B\n";
	c2.afficher();
	cout<<endl;                         */

	// Après la surdéfinition des opérateurs + et *
	Complexe c1, c2;
	c1=A+B;
	c2=A*B;
	cout<<"\n\nVoici c1=A+B\n";
	//c1.afficher();
	cout<<c1;
	cout<<endl;
	cout<<"\n\nVoici c2=A*B\n";
	cout<<c2;
	//c2.afficher();
	cout<<endl;
	cout<<"\n Module de c1 = "<<c1.module()<<endl;
	return 0;
}