#include "str.h"
using namespace std;

int main()
{
	char A[5]="Bon";
	char B[10]="Bon";
	char C[10]="journee";
	str s1(A);
	str s2(B);
	str s3(C);
	s1.affiche();
	s2.affiche();
	str s4=s1+s2;
	cout<<"\n\nS4=S1+S2\n";
	s4.affiche();
	char s=s4[10];
	if(s!='\0')
	   cout<<"\ns4[10]="<<s<<endl;
	else
		cout<<" \n\n Indice incorrecte!\n";
	
	if(s1==s2)
		cout<<" \n s1 egal s2\n";
	else
		cout<<" \ns1 different de s2\n";

	if(s2<s1)
		cout<<" \n s2 vient avant s1\n";
	else
		cout<<" \n s2 ne vient pas avant s1\n";
	return 0;
}