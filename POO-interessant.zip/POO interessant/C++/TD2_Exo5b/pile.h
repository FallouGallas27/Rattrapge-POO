#include <iostream>

typedef struct Pile_elt
{
    int val;
    struct Pile_elt* suiv;
}pile_elt;

typedef pile_elt* pPile;

class pile
{
	private:
		pPile sommet;
   	public:
   		pile();
   		pile(pile&);
   		~pile();
   		void empiler(int);
   		int depiler();
   		int get_sommet()const;
   		bool est_vide()const;
};






















//pile& operator<<(int);
//pile& operator>>();