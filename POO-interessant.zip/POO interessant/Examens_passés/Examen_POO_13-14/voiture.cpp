#include "voiture.h"

Voiture::Voiture(int prix, int portes)
:Vehicule(prix), m_portes(portes)
{}
void Voiture::affiche(ostream& out) const
{
    out << "Ceci est une voiture avec " << m_portes << " et coutant " << m_prix << " euros." << endl;
}
Voiture::~Voiture()
{}

