#ifndef MOTO_H
#define MOTO_H
#include <iostream>
using namespace std;

#include "vehicule.h"


class Moto : public Vehicule
{
    private:
        double m_vitesse;
    public:
        Moto(int prix, double vitesseMax);
        //Construit une moto d'un prix donn� et ayant une certaine vitesse maximale
        virtual void affiche(ostream& out)const;

        virtual ~Moto();   
};

#endif // MOTO_H
