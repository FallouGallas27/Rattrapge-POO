#include "Ensemble.h"
using namespace std;

int main()
{
	ensemble E(5); 
	ensemble E1(5);
	E.afficher();
	cout<<"\nle cardinal est :  "<<E.cardinal(); 
	//E.ajouter(2);
	E<<2;
	cout<<"\nle cardinal est :  "<<E.cardinal();
	E.afficher();
	//E.ajouter(3);
	E<<3;
	E.afficher();
	//E.ajouter(5);
	E<<5;
	E.afficher();
	E<<5<<6<<7;
	E.afficher();
	int c=E%2;
	if(c!=-1)
		cout<<" \n\n 2 est un element de E a la position "<<c<<endl;
	else
		cout<<" \n 2 n est pas un element de E\n";
	//E.supprimer(5);
	//E.supprimer(2);
	//E.supprimer(3);
	E>>5>>2;
	E.afficher();
	/*if(E=E1)
		cout<<" \nLes deux ensembles sont egaux.\n";
	else
		cout<<" \nLes deux ensembles sont differents.\n";*/
	return 0;
}