#ifndef __ADMINISTRATIF__
#define __ADMINISTRATIF__
using namespace std;

class administratif:public salarie
{
	private:
		char* fonction;
	public:
		administratif(char*, char*, char*);
		administratif (const administratif& a);
		administratif& operator=(administratif&);
		~administratif();
		char* get_fonction();
		void afficher();
};
#endif