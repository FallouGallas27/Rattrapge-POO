#include "base.h"
#include "individu.h"
#include <string>

class entreprise : public base
{
	private:
		int identifiant;
		string nom;
		individu directeur(0, "a", "b"); // oubien un constructeur par defaut avec ces valeurs
		//employe salaries[100];
		int nb_salaries;
	public:
		entreprise(int, string, individu, int); // oubien
		//entreprise(int, string, int, string, string, int);  
		~entreprise();
		void affichage();
		int get_id();
	
};