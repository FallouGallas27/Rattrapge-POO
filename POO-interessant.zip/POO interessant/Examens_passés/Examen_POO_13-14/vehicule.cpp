#include "vehicule.h"

using namespace std;

Vehicule::Vehicule(int prix):m_prix(prix)
{}
void Vehicule::affiche(ostream& out) const
{
    out << "Ceci est un vehicule coutant " << m_prix << " euros." << endl;
}

Vehicule::~Vehicule() //M�me si le destructeur ne fait rien, on doit le mettre !
{
	cout<<"\n Appel du destructeur de vehicule";
}
ostream& operator<<(ostream& out ,Vehicule& v)
{
    v.affiche(out);
    return out;
}
