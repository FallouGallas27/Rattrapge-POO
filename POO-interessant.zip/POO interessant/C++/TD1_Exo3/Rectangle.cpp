#include "Rectangle.h"
#include <math.h>
#include <ostream>
using namespace std;

Rectangle::Rectangle(unsigned int x, unsigned int y) // le constructeur
{
	cout<<"\n Appel du constructeur de parametres ("<<x<<", "<<y<<")";
	cout<<" Adresse (objet appelant) = "<<this;
	l=x; // ou this->a=x;
	h=y; // ou this->b=y;
}
//******************************************************************
unsigned int Rectangle::GetLargeur()const
{
	return l;
}
//******************************************************************
unsigned int Rectangle::GetHauteur()const
{
	return h;
}
//******************************************************************
unsigned int Rectangle::perimetre()const
{
	return (2*(l+h));
}
//******************************************************************
unsigned int Rectangle::surface()const
{
	return (l*h);
}
//******************************************************************
void Rectangle::SetLargeur(unsigned int s) 
{
	l=l+s;
}
//******************************************************************
void Rectangle::SetHauteur(unsigned int s) 
{
	h=h+s;
}
//******************************************************************
/*bool Rectangle::compare(const Rectangle &r)
{
	if((l==r.l)&&(h==r.h))
		return true;
	else
		return false;
}*/
//******************************************************************
Rectangle::~Rectangle()
{
	cout<<" \nAppel du destructeur \n";
}
//******************************************************************
bool Rectangle::operator==(Rectangle &r)
{
	if((l==r.l)&&(h==r.h))
		return true;
	else
		return false;
}
//******************************************************************
void Rectangle::afficher()const
{
	cout<<endl;
	for(int i=0; i<h; i++)
	{
		for(int j=0; j<l; j++)
			cout<<" * ";
		cout<<endl;
	}	
}
//******************************************************************
/*ostream& operator<<(ostream& sortie,const Complexe& c)
{
	cout<<"\nAffichage d'un Rectangle sur le flot de sortie\n";
	for(int i=0; i<h; i++)
	{
		for(int j=0; j<l; j++)
			cout<<"*";
		cout<<endl;
	}
	return sortie;	
}*/
