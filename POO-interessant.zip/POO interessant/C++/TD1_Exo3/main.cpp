#include "Rectangle.h"
#include <ostream>
using namespace std;
int main()
{
	Rectangle R1(6, 3), R2(10, 4);
	bool b;
	cout<<"\n\n Nous travaillons avec les rectangles R1(l=6, h=3) et R2(l=10, h=4)\n";
	cout<<"\nLa largeur de R1 est : "<<R1.GetLargeur();
	cout<<"\nLa hauteur de R1 est : "<<R1.GetHauteur();
	cout<<"\n \nVoici R1 \n";
	R1.afficher();
	//cout<<R1;
	cout<<"\n \nVoici R2 \n";
	R2.afficher();
	//cout<<R2;
	cout<<"\nLe perimetre de R1 est : "<<R1.perimetre();
	cout<<"\nLa surface de R1 est : "<<R1.surface();
	cout<<"\n\nNous allons maintenant modifier la largeur de R1 et la hauteur de R2\n";
	R1.SetLargeur(1);
	R2.SetHauteur(1);
	cout<<"\nLa largeur de R1 est : "<<R1.GetLargeur();
	cout<<"\nLa hauteur de R2 est : "<<R2.GetHauteur();
	cout<<"\n\nVoici R1\n";
	R1.afficher();
	//cout<<R1;
	cout<<"\n\nVoici R2\n";
	R2.afficher();
	//cout<<R2;
	// Avant la surdéfinition de l'opérateur ==
  	/*b=R1.compare(R2);
	if(b)
		cout<<"\n\n R1 est egal a R2 \n";
	else
		cout<<"\n\n R1 est different de R2 \n"; */ 

	// Après la surdéfinition de l'opérateur ==
	if(R1==R2)
		cout<<"\n\n R1 est egal a R2 \n";
	else
		cout<<"\n\n R1 est different de R2 \n";
	return 0;
}