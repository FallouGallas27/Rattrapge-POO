#ifndef INDIVIDU_B
#define INDIVIDU_B
#include "base.h"

using namespace std;

class individu : public base
{
	protected:
		int id;
		string nom;
		string prenom;
	private:
		individu(int, string, string);
		virtual~individu();
		void afficher();
		int clef();
		
};

#endif