#ifndef __PROFESSEUR__
#define __PROFESSEUR__

class professeur : public salarie
{
	private:
		char* diplome;
		char* matiere[10];
	public:
		professeur(char*, char*, char*);
		professeur(const professeur& p);
		~professeur();
		char* get_diplome();
		char* get_matiere(int);
		void ajout_matiere(char*);
		professeur& operator=(professeur&);
		void afficher();
};
#endif
