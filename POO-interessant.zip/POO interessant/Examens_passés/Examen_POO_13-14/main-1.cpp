#include <iostream>
#include <vector>
#include "vehicule.h"
#include "voiture.h"
#include "moto.h"
using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    vector <Vehicule*> liste;
    Vehicule v(399);
    Voiture v1(2000,4);
    Voiture v2(3000,2);
    Moto m1(150,4.6);
    Moto m2(220,9.6);
    liste.push_back(&v);
    liste.push_back(&v1);
    liste.push_back(&v2);
    liste.push_back(&m1);
    liste.push_back(&m2);
    cout<<"----------------------------- affichge 1----------------------------"<<endl;
    cout<<v<<v1<<v2<<m1<<m2;
    cout<<"------------------- affichge 2 avec boucle -------------------------"<<endl;
    for(int i=0; i<liste.size();i++)
    {
         cout<<*(liste[i]);
    }
    return 0;
}
