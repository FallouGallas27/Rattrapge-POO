#include "Ensemble.h"
using namespace std;

ensemble::ensemble(int N)
{
	element=new int[N];
	max_e=N;
	card_e=0;	
}
//****************************************************************
int ensemble::cardinal()
{
	return card_e;
}
//****************************************************************
/*int ensemble::contient(int x)const
{
	int i=0;
	while((i<card_e)&&(element[i]!=x))
		i++;
	if(i<card_e) // l'element est trouvé
		return i;
	else
		return -1;
}
//****************************************************************
void ensemble::ajouter(int x)
{
	cout<<endl;
	if(card_e==max_e)
		cout<<" Ajout impossible : ensemble plein!";
	else
	{
		if((*this).contient(x)!=-1)
			cout<<x<<" est deja dans l ensemble\n";
		else
		{
			element[card_e]=x;
			card_e++;
		}
	}
}
//****************************************************************
void ensemble::supprimer(int x)
{
	cout<<endl;
	if((*this).contient(x)==-1)
		cout<<endl<<x<<" n est pas dans l ensemble.";
	else
	{
		int p=(*this).contient(x);
		for(int i=p; i<card_e-1; i++)
			element[i]=element[i+1];
		card_e--;
	} 
}*/
//****************************************************************
ensemble::~ensemble() // Destructeur
{
	cout<<" \n\nAppel du Destructeur\n";
	if(element)
		delete element;
}
//****************************************************************
void ensemble::afficher()
{
	cout<<endl;
	if(card_e==0)
		cout<<"\n E = { } \n";
	else
	{
		
		if(card_e==1)
			cout<<" \nE = { "<<element[0]<<" }";
		else
		{
			cout<<"  E = { ";
			for(int i=0; i<card_e-1; i++)
				cout<<element[i]<<" , ";
			cout<<element[card_e-1];
			cout<<" }";
		}
	}
}
//****************************************************************
ensemble::ensemble(ensemble& e)
{
	max_e=e.max_e;
	card_e=e.card_e;
	element=new int[max_e];
	for(int i=0; i<card_e; i++)
		element[i]=e.element[i];
}
//****************************************************************
ensemble& ensemble::operator<<(int x)
{
	cout<<endl;
	if(card_e==max_e)
	{	cout<<" Ajout impossible : ensemble plein!";
		return (*this);
	}
	else
	{
		if((*this)%x!=-1)
		{	cout<<endl<<x<<" est deja dans l ensemble\n";
			return (*this);
		}
		else
		{
			element[card_e]=x;
			card_e++;
			return (*this);
		}
	}

}
//****************************************************************
ensemble& ensemble::operator>>(int x)
{
	cout<<endl;
	if((*this)%x==-1)
	{	cout<<"\n"<<x<<" n est pas dans l ensemble.";
		return (*this);
	}
	else
	{
		int p=(*this)%x;
		for(int i=p; i<card_e-1; i++)
			element[i]=element[i+1];
		card_e--;
		return (*this);
	} 
}
//****************************************************************
int ensemble::operator%(int x)
{
	int i=0;
	while((i<card_e)&&(element[i]!=x))
		i++;
	if(i<card_e) // l'element est trouvé
		return i;
	else
		return -1;
}
//****************************************************************
/*bool ensemble::operator=(ensemble e)
{
	if(card_e!=e.card_e)
		return false;
	else
	{
		int i;
		while((i<card_e)&&(element[i]==e.element[i]))
			i++;
		if(i==card_e)
			return true;
		else
			return false;
	}
}*/
//****************************************************************
ensemble ensemble::operator+(ensemble e)
{
	ensemble ens(max_e+e.max_e);
	int i, j;
	for(i=0; i<card_e; i++)
		ens.element[i]=element[i];
	for(j=0; j<card_e+e.card_e; j++)
		ens.element[j+i]=e.element[j];
	return ens;
}
//****************************************************************
ensemble ensemble::operator*(ensemble e)
{
	ensemble inter(max_e); 
	if(card_e==0||e.card_e==0)
		return inter;
	else
	{
		int i=0;
		while((i<max_e+e.max_e)&&(element[i]==e.element[i]))
		{
			inter<<element[i];
			i++;
		}
		return inter;
	}
}
//****************************************************************