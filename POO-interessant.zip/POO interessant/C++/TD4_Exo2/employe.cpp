using namespace std;
#include "employe.h"


employe::employe(int i, string n, string p, string c):individu(i, n, p)
{
	
	competence=c;
	cout<<"\n Appel du constructeur de employe\n";
}

/***********************************************************************/
employe::~employe()
{
	cout<<"\n Appel du destructeur de employe\n";
}
void employe::afficher()
{
	cout<<"\n ----------- Affichage employe -----------\n";
	individu::afficher();
	cout<<"\n Competence : "<<competence<<endl;
	cout<<endl;
}
int employe::clef()
{
	 int c=individu::clef();
	 return c;
}