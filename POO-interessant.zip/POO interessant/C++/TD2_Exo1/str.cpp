#include "str.h"
using namespace std;

str::str()
{
	cout<<" \nAppel du constructeur 1\n";
	taille=0;
	chaine=NULL;
}
//***********************************************************************
str::str(char* ch) // on copie ch dans chaine
{
	cout<<" \nAppel du constructeur 2\n";
	char *adr=ch; //On donne à adr l'adresse de ch(il pointe sur la mm zone que ch)
	int a=0;
	while(*adr!='\0') // On cherche la taille de ch
	{
		a++;
		adr++;
	} // à la sortie a=taille(ch)
	taille=a; // On donne à la taille de l'objet appelant la taille de ch
	chaine=new char[taille]; // allocation dynamique
	for(int i=0; i<taille; i++) // Copie des caractères ch dans chaine
		chaine[i]=ch[i];
}
//***********************************************************************
str::str(str& s)
{
	cout<<" \nAppel du constructeur de recopie\n";
	taille=s.taille;
	chaine=new char[taille];
	for(int i=0; i<taille; i++)
		chaine[i]=s.chaine[i];
}
//***********************************************************************
str& str::operator=(const str& s)
{
	if(chaine)
		delete chaine;
	taille=s.taille;
	chaine=new char[taille];
	for(int i=0; i<taille; i++)
		chaine[i]=s.chaine[i];
	return (*this);

}
//***********************************************************************
bool str::operator==(const str& s)
{
	if(taille!=s.taille)
		return false;
	else
	{
		int i=0;
		while((i<taille)&&(chaine[i]==s.chaine[i]))
			i++;
		if(i==taille)
			return true;
		else
			return false;
	}
}
//***********************************************************************
str str::operator+(const str& s)
{
	str s1;
	if(!s.chaine)
		return(*this);
	else
	{
		int dim=taille+s.taille;
		int i, j;
		s1.taille=dim;
		s1.chaine=new char[dim];
		for(i=0; i<taille; i++)
			s1.chaine[i]=chaine[i];
		for(j=0; j<dim; j++)
			s1.chaine[j+i]=s.chaine[j];
		return s1;
	}
}
//***********************************************************************
//char& str::operator[](int a)
char str::operator[](int i)
{
	//char b='\0';
	char c='\0';
	if((i<=taille)&&(i>=0))
		return chaine[i];
	else
		return c;
}
//***********************************************************************
str::~str()
{
	cout<<" \nAppel du destructeur \n";
	if(chaine)
		delete chaine;
}
//***********************************************************************
void str::affiche()
{
	cout<<endl;
	for(int i=0; i<taille; i++)
		cout<<chaine[i];
	cout<<endl;
}
//*************************************************************************
bool str::operator<(str s)
{
    int i=0;
    while((i<taille)&&(chaine[i]==s.chaine[i]))
 		i++;
    if(i==taille)
    	return false;
    else
    {
    	if(chaine[i]<s.chaine[i])
    		return true;
    	else
    		return false;
    }

}
	