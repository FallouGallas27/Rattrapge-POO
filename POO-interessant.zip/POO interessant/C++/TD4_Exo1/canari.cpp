#include <iostream>
#include "oiseau.h"
#include "canari.h"
using namespace std;

canari::canari(string n):oiseau(n)
{
	cout<<"\n Appel du constructeur de canari\n";
}
canari::~canari()	
{
	cout<<"\n Appel du destructeur de canari\n";
}
void canari::exprime_toi()
{
    cout<<endl;
	cout<<nom;
	cout<<" cui-cui\n";
}