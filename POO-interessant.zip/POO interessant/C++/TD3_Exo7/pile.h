#ifndef PILE_H
#define PILE_H

class pile : private Liste
{
	public:
		pile();
		~pile();
		void empiler(void*);
		void* depiler();
		void* get_sommet();
		bool est_vide();
		int get_longueur();
};

#endif