#include "document.h"

document::document(char* t)
{
	titre=new char[srten(t)+1];
	mot_cle=new char*[10];
	for(int i=0; i<10; i++)
		mot_cle[i]=NULL;
}

document::~document()
{
	if(mot_cle)
	{
		for(int i=0; i<10; i++)
		{	if(mot_cle[i])
				delete mot_cle[i]
		}
		delete mot_cle;
	}
	if(titre)
		delete titre;
}
