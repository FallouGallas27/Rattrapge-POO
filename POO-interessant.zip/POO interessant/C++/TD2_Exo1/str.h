#include<iostream>

class str
{
	private:
		int taille;
		char* chaine;
	public:
		str();      // Constructeur 1
		str(char*); // Constructeur 2
		str(str&);  // Constructeur de recopie
		~str();     // destructeur
		// Surdéfinition des opérateurs =, ==, +, [] et <
		str& operator=(const str&);
		bool operator==(const str&);
		str operator+(const str&);
		//char& operator[](int);
		char operator[](int);
		bool operator<(str);
		void affiche();
};