#include "salarie.h"
#include "administratif.h"
#include "professeur.h"
#include <iostream>
using namespace std;

int main()
{
	professeur P("FALL", "Aliou", "DEUG");
	salarie S("NDIAYE", "Modou");
	//professeur p=P; // Constructeur de recopie de professeur
	//cout<<" Nom (professeur)    : "<<p.get_nom()<<endl;
	administratif A("FALL", "Amadou", "Directeur");
	P.ajout_matiere("Maths");
	P.ajout_matiere("Informatique");
	P.ajout_matiere("Informatique");
	/*cout<<" Nom (salarie)    : "<<S.get_nom()<<endl;
	cout<<" Prenom (salarie) : "<<S.get_prenom()<<endl;
	cout<<" Diplome (prof)   : "<<P.get_diplome()<<endl;
	cout<<"\n Matiere[0] : "<<P.get_matiere(0);
	cout<<"\n Matiere[1] : "<<P.get_matiere(1);*/
	cout<<endl;
	/*P.afficher();
	S.afficher();
	A.afficher();*/

	salarie *s; 
	int rep;
	cout << "\n Salarie (0) ou professeur (1) ou administratif (2) : ";
	cin >> rep;
	switch(rep) 
	{
		case 0 : s = &S; break;
 		case 1 : s = &P; break;
 		case 2 : s = &A; break;
 		default : s = NULL;
	}
	if (s) s->afficher();
	return 0;
}