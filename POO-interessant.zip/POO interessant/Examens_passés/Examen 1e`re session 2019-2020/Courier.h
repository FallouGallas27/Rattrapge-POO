#ifndef COURIER_H_INCLUDED
#define COURIER_H_INCLUDED
#include<iostream>
#include<string>
#include<cstdlib>
using namespace std;

class Courier
{
protected :
	double poids;
	string mode;
	string adresseexp;
	string adressedest;
	
public :
	Courier(double,string,string,string);
    virtual ~Courier();
	virtual double PrixTimbre()=0;
	virtual void afficher()const;
	friend ostream &operator<<(ostream&,Courier&);

	//virtual void afficher(ostream&)const;
};

#endif // COURIER_H_INCLUDED
