#ifndef VEHICULE_H
#define VEHICULE_H
#include <iostream>
using namespace std;

class Vehicule
{
    protected:
        int m_prix;
        
    public:
        Vehicule(int prix); //Construit un v�hicule d'un certain prix
        virtual void affiche(ostream& out) const;
        friend ostream& operator<<(ostream& out ,Vehicule& v);
        virtual ~Vehicule(); //Remarquez le 'virtual'    
};

#endif // VEHICULE_H
