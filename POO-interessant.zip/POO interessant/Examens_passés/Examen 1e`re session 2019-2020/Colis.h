#ifndef COLIS_H_INCLUDED
#define COLIS_H_INCLUDED
#include"Courier.h"
using namespace std;

class Colis :public Courier
{
private:
	double volume;
public:
	Colis(double,string,string,string,double);
	virtual ~Colis();
	virtual double PrixTimbre();
    virtual void afficher()const;

	// virtual void afficher(ostream&)const;
};

#endif // COLIS_H_INCLUDED
