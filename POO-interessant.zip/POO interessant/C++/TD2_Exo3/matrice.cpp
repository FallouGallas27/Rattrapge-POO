#include "matrice.h"
using namespace std;

matrice::matrice(int l, int c)
{
	cout<<" \nAppel du constructeur pour l objet d adresse : "<<this<<endl;
	matrice *m=NULL;
    m=new matrice;
    if(m==NULL)
        return NULL;
    m->nb_lignes=l;
    m->nb_colonnes=c;
    m->element=new int*[l];
    if(m->element==NULL)
        return NULL;
    for(int i=0; i<l; i++)
    {    
        m->element[i]=new int[c];
        if(m->element[i]==NULL)
            return NULL;
        for(int j=0; j<c; j++)
            m->GetElement[i][j]=0;
    }
    return m;
}
//**********************************************************
matrice::~matrice()
{
	cout<<" \nAppel du destructeur pour l objet d adresse : "<<this<<endl;
	if((*this))
     {
          if((*this)->element)
          {
               for(int i=0; i<m->nb_lignes; i++)
               {
                    if((*this)->element[i])
                         delete (*this)->element[i];
               }
               delete (*this)->element;
          }
          delete (*this);
     }
}
//**********************************************************
int GetElement(int l, int c)
{
	return element[l][c];
}
//**********************************************************
void SetElement(int x, int l, int c)
{
	element[l][c]=x;
}
//**********************************************************
matrice matrice::produit(matrice m)
{
	if(nb_colonnes==m->nb_lignes)
    {
        matrice p(nb_lignes, m->nb_colonnes);
        if(p==NULL)
            return NULL;
        int i, j, k;
        for(i=0; i<nb_lignes; i++)
            for(j=0; j<m->nb_colonnes; j++)
                for(k=0; k<nb_colonnes; k++)
                    p->element[i][j]+=element[i][k]*m->element[k][j];
        return p;
    }
    else 
        return NULL;
}
//**********************************************************
void matrice::afficher()
{
	cout<<"\n voici la matrice : "<<endl;
     for(int i=0; i<nb_lignes; i++)
     {
          for(int j=0; j<nb_colonnes; j++)
               cout<<" "<<element[i][j]<<" ";
               cout<<endl;
     }
     cout<<endl;
}
//**********************************************************
matrice& matrice::operator()(int i, int j)
{
	return element[i][j];
}