#include <iostream>
#include "chat.h"
#include "mammifere.h"
using namespace std;

chat::chat(string n):mammifere(n)
{
	cout<<"\n Appel du constructeur de chat\n";
}
chat::~chat()
{
	cout<<"\n Appel du destructeur de chat\n";
}
void chat::exprime_toi()
{
	cout<<endl;
	cout<<nom;
	cout<<" miaou \n";
}