#ifndef SOURIS_H
#define SOURIS_H
#include "mammifere.h"
using namespace std;

class souris:public mammifere
{
	public:
		souris(string);
		virtual~souris();
		void exprime_toi();	
};
#endif