#include "str.h"

class strBis: public str
{
	private:
		bool italic;
		bool gras;
		bool colorie;
	public:
		strBis();
		strBis(char*s, ):str(s);
		strBis(str&, ):str(s);
		strBis(strBis&);
		~strBis();
		strBis& operator=(strBis&);
		strBis(str&);
		void mise_en_italic();
		void mise_en_gras();
		void colorier();
		void afficher();

};