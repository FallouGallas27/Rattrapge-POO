#ifndef ANIMAL_H
#define ANIMAL_H
#include <string>
using namespace std;

class animal // classe abstraite
{
	protected:
		string nom;
	public:
		animal(string);
		virtual~animal();
		virtual void exprime_toi()=0; // fonction virtuelle pure
};
#endif