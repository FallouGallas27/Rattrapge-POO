
#include "base.h"
#include "individu.h"
#include "employe.h"
#include "entreprise.h"


int main()
{
	individu directeur(241, "FALL", "Modou");
	// On peut aussi créer un autre individu de nom directeur
	employe E1(241, "NDIAYE", "Bassé", "Programmeuse");
	entreprise E(21, "Apple", directeur, 6);
	base *tab;
	tab[0]=&directeur;
	tab[1]=&E1;
	tab[2]=&E;
	for(int i=0; i<3; i++)
	{
		tab[i]->afficher();
		//tab[i]->clef();
	}
}