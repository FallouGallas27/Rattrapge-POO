#include"enseignant.h"
//#include<cstring>
using namespace std;

int main()
{
	char ch1[20]="DIOP";
	cout<<strlen(ch1);
	char *n=ch1;
	char ch2[20]="Modou";
	char *p=ch2;
	char ch3[20]="Doctorat";
	char *d=ch3;
	enseignant ens(n, p, d);
	ens.afficher();
	char m1[20]="POO";
	char *mat1=m1;
	char m2[20]="algo";
	char *mat2=m2;
	/*ens.ajout_matiere(mat1);
	ens.ajout_matiere(mat2);*/
	ens<<mat1<<mat2;
	ens.afficher();
	ens>>mat2;
	ens.afficher();
	return 0;
}