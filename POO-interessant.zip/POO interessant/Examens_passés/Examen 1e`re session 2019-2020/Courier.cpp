#include"Courier.h"
using namespace std;

Courier ::Courier(double p, string m, string adrexp,string adrdest)
{
	poids=p;
	mode=m;
	adresseexp=adrexp;
	adressedest=adrdest;
    cout<<"\nAppel du constructeur de la classe Courier\n";
}

Courier ::~Courier()
{
    cout<<"Appel du destructeur de courrier\n";

}

/*void Courier:: afficher(ostream &out)const
{
    cout<<endl;
    out<<"Poids : "<<poids<<endl;
    out<<"Mode : "<<mode<<endl;
    out<<"Adresse expedition : "<<adresseexp<<endl;
    out<<"Adresse destination : "<<adressedest<<endl;
}*/

void Courier:: afficher()const
{
    cout<<endl;
    cout<<"Poids : "<<poids<<endl;
    cout<<"Mode : "<<mode<<endl;
    cout<<"Adresse expedition : "<<adresseexp<<endl;
    cout<<"Adresse destination : "<<adressedest<<endl;
}
ostream &operator<<(ostream &out, Courier &C)
{
    cout<<endl;
    C.afficher();
    /*out<<"Poids : ";
    out<<C.poids<<endl;
    out<<"Mode : ";
    out<<C.mode<<endl;
    cout<<"Adresse expedition : ";
    out<<C.adresseexp<<endl;
    cout<<"Adresse destination : ";
    out<<C.adressedest<<endl;*/
    return out;

}





