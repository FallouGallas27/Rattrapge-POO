#include"Colis.h"
using namespace std;

Colis ::Colis(double p, string m, string adrexp, string adrdest, double v):Courier(p,m,adrexp,adrdest)
{
	volume=v;
    cout<<"\nAppel du constructeur de la classe Colis\n";
}

Colis ::~Colis()
{
    cout<<"Appel du destructeur de classe Colis\n";
}

double Colis ::PrixTimbre()
{
    if(mode=="normal")
        return (0.25*volume+1.0*poids/1000);
    return (0.25*volume+2.0*poids/1000);
}

/*void Colis:: afficher(ostream &out) const
{
    out<<"Ceci est un colis\n";
    Courier::afficher(out);
    out<<"Volume : "<<volume<<endl;
}*/

void Colis:: afficher() const
{
    cout<<"Ceci est un colis\n";
    Courier::afficher();
    cout<<"Volume : "<<volume<<endl;
    //cout<<"Prix timbre : "<<PrixTimbre();
}








