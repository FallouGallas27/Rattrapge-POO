#ifndef COMPLEXE_H_INCLUDED
#define COMPLEXE_H_INCLUDED

#include <iostream>

class Complexe
{
	private:
		double a;
		double b;
	public:
		Complexe(double x=0, double y=0);
		double reelle()const;
		double imaginaire()const;
		double module()const;

/*    Avant la surdefinition des opérateurs + et *

	   Complexe ajouter(const Complexe &c)const;
		Complexe multiplier(const Complexe &c)const;    */

		// Surdéfinition des opérateurs + et * 
		inline Complexe operator+(Complexe &c); // inline n'est pas ici obligatoire
		inline Complexe operator*(Complexe &c);

/*    Sans inline
      Complexe operator+(Complexe &c); 
		Complexe operator*(Complexe &c);     */

/*		Avant la surdéfinition de l'opérateur <<
		void afficher()const;				*/

		//Surdéfinition de l'opérateur <<
	   friend ostream& operator<<(ostream& sortie,Complexe& c);
};

/* Si on avait pas utilisé inline, la définition des fonctions ci-dessous
   serait dans le fichier complexe.cpp sans inline */
inline Complexe Complexe::operator+(Complexe &c)
{
	Complexe A;
	A.a=a+c.a;
	A.b=b+c.b;
	return A;
}
inline Complexe Complexe::operator*(Complexe &c)
{
	Complexe A;
	A.a=(a*c.a)-(b*c.b);
	A.b=(a*c.b)+(b*c.a);
	return A;
}
#endif