#ifndef OISEAU_H
#define OISEAU_H
using namespace std;
#include "animal.h"
class oiseau : public animal
{
	public:
		oiseau(string);
		virtual~oiseau();
		virtual void exprime_toi()=0;
};
#endif