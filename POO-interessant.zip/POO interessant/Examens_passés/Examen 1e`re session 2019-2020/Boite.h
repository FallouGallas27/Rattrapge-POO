#ifndef BOITE_H_INCLUDED
#define BOITE_H_INCLUDED
#include<iostream>
//#include"Courier.h"
#include"Lettre.h"
#include"Colis.h"
using namespace std;

class Boite
{
private:
	int hauteur;
	double volume;
	Courier **elements;
	// On suppose ici que la hauteur de la boite est la taille maximale

public:
	Boite(int,double);
	~Boite();
	void ajouter(Courier*);
	friend ostream &operator<<(ostream&,Boite&);
 /*  Afficher la boite sans surdéfinir  
	void afficher();
 */

};




#endif // BOITE_H_INCLUDED
