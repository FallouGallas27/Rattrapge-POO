#ifndef CHAT_H
#define CHAT_H
#include "mammifere.h"
using namespace std;
class chat:public mammifere
{
	public:
		chat(string);
		virtual~chat();
		void exprime_toi();
};
#endif