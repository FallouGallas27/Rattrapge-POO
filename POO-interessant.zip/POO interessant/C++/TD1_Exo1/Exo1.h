#include<iostream>
#include<iomanip>

typedef struct matrice
{
	int nb_lignes;
	int nb_colonnes;
	float **elements;	
}Matrice;

Matrice* creer_matrice(int, int);
Matrice* saisir_matrice(Matrice*);
void detruire_matrice(Matrice*);
void afficher_matrice(Matrice*);
Matrice* transposee_matrice(Matrice*);
Matrice* matrice_produit(Matrice*, Matrice*);
