#include "moto.h"
using namespace std;
Moto::Moto(int prix, double vitesseMax)
:Vehicule(prix), m_vitesse(vitesseMax)
{}
void Moto::affiche(ostream& out) const
{
    out << "Ceci est une moto allant a " << m_vitesse << " km/h et coutant " << m_prix << " euros." << endl;
}
Moto::~Moto()
{}

