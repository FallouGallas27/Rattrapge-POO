#ifndef Liste_H
#define Liste_H

struct place
{
	void* element;
	place* suivant;	
};

class Liste
{
	private:
		int m_longueur;
		place* m_premier;
		place* m_courant;
	public:
		Liste();
		Liste(Liste&);
		~Liste();
		Liste& operator=(Liste&);
		int ajouter(int i, void* pe);
		int supprimer(int i);
		void* ieme(int i);
		int longueur(){ return (m_longueur);}
		void init(){ m_courant=m_premier->suivant;}
		int existe(){ return (m_courant!=0);}
		void* prochain()
		{
			void* temp=m_courant->element;
			m_courant=m_courant->suivant;
			return temp;
		}
};
 #endif