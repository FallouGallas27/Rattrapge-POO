#ifndef __SALARIE__
#define __SALARIE__

class salarie
{
	private:
		char* nom;
		char* prenom;
	public:
		salarie(char*, char*);
		salarie(const salarie&);
		~salarie();
		char* get_nom()const;
		char* get_prenom()const;
		salarie& operator=(const salarie&);
		//void afficher();  typage statique
		virtual void afficher(); //typage dynamique
};
#endif