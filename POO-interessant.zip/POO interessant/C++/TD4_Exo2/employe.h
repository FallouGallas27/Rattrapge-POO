#include "individu.h"
using namespace std;

class employe : public individu
{
	private:
		string competence;
	public:
		employe(int, string, string, string);
		~employe();
		void afficher();
		int clef();
};