#include "complexe.h"
#include <math.h>
#include <iostream>
using namespace std;

Complexe::Complexe(double x, double y)
{
	cout<<"\n Appel du constructeur pour l'objet de parametres ("<<x<<", "<<y<<")";
	cout<<" Adresse (objet appelant) = "<<this;
	a=x; // ou this->a=x;
	b=y; // ou this->b=y;
}
//******************************************************************
double Complexe::reelle()const
{
	return a;
}
//******************************************************************
double Complexe::imaginaire()const
{
	return b;
}
//******************************************************************
double Complexe::module()const
{
	double m=(a*a)+(b*b);
	return (sqrt(m));
}
//******************************************************************
/*Complexe Complexe::ajouter(const Complexe &c)const
{
	Complexe c2; //ou Complexe c2(0,0) mais on a déja initialisé dans le constructeur
	c2.a=a+c.a;
	c2.b=b+c.b;
	return c2;
}
//******************************************************************
Complexe Complexe::multiplier(const Complexe &c)const
{
	Complexe c2;
	c2.a=(a*c.a)-(b*c.b);
	c2.b=(a*c.b)+(b*c.a);
	return c2;
}*/
//******************************************************************
/*void Complexe::afficher() const
{
	cout<<" "<<a<<" + "<<b<<"i";
	// cout<<"<<"<<" "<<a<<" + "<<b<<"i"<<" "<<">>";
}*/
//******************************************************************
ostream& operator<<(ostream& sortie,Complexe& c)
{
	//cout<<"Affichage d'un complexe sur le flot de sortie\n";
	sortie<<c.a<<" + "<<c.b<<"i";
	return sortie;
}
