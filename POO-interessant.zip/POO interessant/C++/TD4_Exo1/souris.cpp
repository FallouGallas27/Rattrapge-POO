#include <iostream>
#include "mammifere.h"
#include "souris.h"
using namespace std;

souris::souris(string n):mammifere(n)
{
	cout<<"\n Appel du constructeur de souris\n";
}
souris::~souris()
{
	cout<<"\n Appel du destructeur de souris\n";
}
void souris::exprime_toi()	
{
	cout<<endl;
	cout<<nom;
	cout<<" couic\n";
}