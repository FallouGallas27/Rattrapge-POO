#ifndef LETTRE_H_INCLUDED
#define LETTRE_H_INCLUDED
#include"Courier.h"

class Lettre :public Courier
{
private:
	string format;
public:
	Lettre(double,string,string,string,string);
	virtual ~Lettre();
	double PrixTimbre();
	virtual void afficher()const;
};


#endif // LETTRE_H_INCLUDED
