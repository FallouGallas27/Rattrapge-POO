
#include "entreprise.h"


/*entreprise::entreprise(int i1, string n1, int i2, string n2, string p, int nbs):directeur(i2, n2, p)
{
	identifiant=i1;
	nom=n1;
	nb_salaries=nbs;
	cout<<"\n Appel du constructeur de entreprise\n";
}*/

// oubien 

entreprise::entreprise(int i, string n, individu E, int nb):directeur(E)
{
	identifiant=i;
	nom=n;
	nb_salaries=nb;
	cout<<"\n Appel du constructeur de entreprise\n";
}
entreprise::~entreprise()
{
	cout<<"\n Appel du destructeur de entreprise\n";
}
void entreprise::affichage()
{
	cout<<"\n ---------- affichage de entreprise ----------\n";
	cout<<" Identifiant : "<<identifiant;
	cout<<" Nom : "<<nom;
	cout<<" Nombre de salaries : "<<nb_salaries;
	cout<<" Directeur : "<<individu::afficher();
	/*for(int i=0; i<100 ; i++)
	{
		salaries[i].afficher();
	}*/
}
int entreprise::get_id()
{
	return identifiant;
}