#include"Boite.h"

using namespace std;

int main()
{

    Boite B(5,8); // Boite EXPEDIDIF(5,8);
    Courier *T[4]; // typage dynamique
	Lettre L1(80,"normal","Thies","Dakar","A4");
	Colis C1(2.30,"express","Saint-Louis","Mbour",3000);

    /*    
        Typage dynamique

    cout<<endl;
    T[0]=&L1;
    T[0]->afficher();
    cout<<C1;

        On a pu écrire cout<<c1; grâce à la surdéfinition de 
        l'opérateur << dans la classe courrier
        on peut mettre directement cout<<C1<<L1;
     
     */
    B.ajouter(&L1);
    B.ajouter(&C1);
    cout<<B; // oubien B.afficher();
    cout<<endl;
   // cout<<*(B.elements[1]);
	return 0;
}
