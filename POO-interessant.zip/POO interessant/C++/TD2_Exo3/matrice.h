#include<iostream>

class matrice
{
	private:
		int nb_lignes;
		int nb_colonnes;
		int **element;
	public:
		matrice(int, int);
		~matrice();
		int GetElement(int, int);
		void SetElement(int, int, int);
		matrice produit(matrice);
		matrice& operator()(int , int);
		void afficher();
};