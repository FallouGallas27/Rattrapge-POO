#ifndef VOITURE_H
#define VOITURE_H

#include "vehicule.h"
#include <iostream>
using namespace std;


class Voiture : public Vehicule
{
    private:
        int m_portes;
    public:
        Voiture(int prix, int portes);
        //Construit une voiture dont on fournit le prix et le nombre de portes
        virtual void affiche(ostream& out) const;


        virtual ~Voiture();   
};

#endif // VOITURE_H
