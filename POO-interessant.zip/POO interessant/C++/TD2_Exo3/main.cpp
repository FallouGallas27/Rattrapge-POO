#include "matrice.h"
int main()
{
	matrice m(3,3);
	m.afficher();
}