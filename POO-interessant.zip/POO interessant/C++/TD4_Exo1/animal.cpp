#include <iostream>
#include <string>
#include "animal.h"
using namespace std;

animal::animal(string n)
{
	nom=n;
	cout<<"\n Appel du constructeur de animal\n";
}

animal::~animal()
{
	cout<<"\n Appel du destructeur de animal\n";
}
