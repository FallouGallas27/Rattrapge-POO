#include "Exo1.h"
using namespace std;

Matrice* creer_matrice(int l, int c)
{
     Matrice *m=NULL;
     m=new Matrice;
     if(m==NULL)
          return NULL;
     m->nb_lignes=l;
     m->nb_colonnes=c;
     m->elements=new float*[l];
     if(m->elements==NULL)
          return NULL;
     for(int i=0; i<l; i++)
     {    
          m->elements[i]=new float[c];
          if(m->elements[i]==NULL)
               return NULL;
          for(int j=0; j<c; j++)
                    m->elements[i][j]=0.0;
     }
     return m;
}
//*****************************************************
Matrice* saisir_matrice(Matrice*m)
{
     cout<<"On va saisir les elements de la matrice."<<endl;
     int i, j;
     for(i=0; i<m->nb_lignes; i++)
     {
          for(j=0; j<m->nb_colonnes; j++)
          {
               cout<<"M["<<i<<"]"<<"["<<j<<"] = ";
               cin>>m->elements[i][j];
          }
     }
     return m;     
}
//*****************************************************
void detruire_matrice(Matrice *m)
{
     if(m)
     {
          if(m->elements)
          {
               for(int i=0; i<m->nb_lignes; i++)
               {
                    if(m->elements[i])
                         delete m->elements[i];
               }
               delete m->elements;
          }
          delete m;
     }
}
//*****************************************************
void afficher_matrice(Matrice *m)
{
     cout<<"\n voici la matrice : "<<endl;
     for(int i=0; i<m->nb_lignes; i++)
     {
          for(int j=0; j<m->nb_colonnes; j++)
               cout<<" "<<m->elements[i][j]<<" ";
               cout<<endl;
     }
     cout<<endl;
}
//******************************************************
Matrice* transposee_matrice(Matrice *m)
{
     Matrice* T;
     int i, j;
     T=creer_matrice(m->nb_colonnes, m->nb_lignes);
     if(T!=NULL)
     {
          for(i=0; i<m->nb_lignes; i++)
               for(j=0; j<m->nb_colonnes; j++)
                    T->elements[j][i]=m->elements[i][j];
          return T;
     }
     else 
          return NULL;     
}
//******************************************************
Matrice* matrice_produit(Matrice* m1, Matrice* m2)
{
     if(m1->nb_colonnes==m2->nb_lignes)
     {
          Matrice *p;
          p=creer_matrice(m1->nb_lignes, m2->nb_colonnes);
          if(p==NULL)
               return NULL;
          int i, j, k;
          for(i=0; i<m1->nb_lignes; i++)
               for(j=0; j<m2->nb_colonnes; j++)
                    for(k=0; k<m1->nb_colonnes; k++)
                         p->elements[i][j]+=m1->elements[i][k]*m2->elements[k][j];
          return p;
     }
     else 
          return NULL;

}



 