#include"Boite.h"

Boite ::Boite(int h, double v)
{
	hauteur=h;
	volume=v;
	elements=new Courier*[hauteur];
	for(int i=0 ; i<hauteur ; i++)
        elements[i]=NULL;
    cout<<"\nAppel du constructeur de la classe Boite\n";
}

Boite ::~Boite()
{
	if(elements)
    {
        for(int i=0 ; i<hauteur ; i++)
            if(elements[i])
                delete elements[i];
        delete elements;

    }
    cout<<"\nAppel du destructeur de la classe Boite\n";
}

void Boite ::ajouter(Courier *C)
{
    int i=0;
    while(i<hauteur && elements[i]!=NULL)
        i++;
    if(i>=hauteur)
        cout<<"Boite pleine";
    else
        elements[i]=C;
}

/*  Afficher la boite sans surdéfinition

void afficherBoite()
{
    cout<<endl;
    int i=0;
    while(i<hauteur && elements[i]!=NULL)
    {
        cout<<endl;
        elements[i]->afficher();
        out<<"Prix timbre = "; 
        out<<elements[i]->PrixTimbre();
        i++;
        cout<<endl;
    }
}*/

ostream &operator<<(ostream &out,Boite &B)
{
    cout<<endl;
    int i=0;
    while(i<B.hauteur && B.elements[i]!=NULL)
    {
        cout<<endl;
        B.elements[i]->afficher();
        out<<"Prix timbre = "; 
        out<<B.elements[i]->PrixTimbre();
        i++;
        cout<<endl;
    }
    return out;

    /* Ici on affiche le courrier et son prix de timbre, mais on pouvait
       afficher le prix du timbre dans l'affichage des courriers 
       ainsi quand on affiche la boite, chaque courrier s'affiche avec 
       toutes ses informations (Prix_timbre y compris)
    */
    
}
