#ifndef MAMMIFERE_H
#define MAMMIFERE_H
#include "animal.h"
using namespace std;
class mammifere:public animal 
{
	public:
		mammifere(string);
		virtual~mammifere();	
		virtual void exprime_toi()=0;
};
#endif