#include <iostream>
#include "animal.h"
#include "oiseau.h"
using namespace std;

oiseau::oiseau(string n):animal(n)
{
	cout<<"\n Appel du constructeur de oiseau\n";
}
oiseau::~oiseau()
{
	cout<<"\n Appel du destructeur de oiseau\n";
} 