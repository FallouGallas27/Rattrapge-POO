#ifndef COMPLEXE_H_INCLUDED
#define COMPLEXE_H_INCLUDED
#include <iostream>
#include <ostream>
using namespace std;
class Rectangle
{
	private:
		unsigned int l;
		unsigned int h;
	public:
		Rectangle(unsigned int, unsigned int); // le constructeur
		unsigned int GetLargeur()const;
		unsigned int GetHauteur()const;
		unsigned int perimetre()const;
		unsigned int surface()const;
		void SetLargeur(unsigned int); 
		void SetHauteur(unsigned int); 
		~Rectangle();
		
		//Avant la surdéfinition de l'oprérateur ==
	    //bool compare(const Rectangle &r);

	     //Surdéfinition de l'opérateur ==
		bool operator==(Rectangle &r);

		// Avant la surdéfinition de l'opérateur <<
		void afficher()const;

		// Surdéfinition de l'opérateur <<
		//friend ostream& operator<<(ostream& sortie,const Complexe& c);
};
#endif
