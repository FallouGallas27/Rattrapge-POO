#include <iostream>

class ensemble
{
	private:
		int max_e;
		int card_e;
		int *element;
	public:
		ensemble(int); // Constructeur
		int cardinal();
		~ensemble(); // Destructeur
	/*  int contient(int)const; // On retrourne la position de l'element
		void ajouter(int);
		void supprimer(int);        */
		void afficher();
		ensemble(ensemble&); // Constructeur de recopie

	//  surdéfinition des opérateurs <<(ajout), >>(suppression), = et %(contient)
		ensemble& operator<<(int);
		ensemble& operator>>(int);
		int operator%(int);
		//bool operator=(ensemble);
		ensemble operator+(ensemble);
		ensemble operator*(ensemble);
};