#ifndef CANARI_H
#define CANARI_H
using namespace std;
class canari:public oiseau
{
	public:
		canari(string);
		virtual~canari();	
		void exprime_toi();
};

#endif