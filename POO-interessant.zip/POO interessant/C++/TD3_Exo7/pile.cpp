#include <iostream>
#include "pile.h"

/*****************************************************************/
pile::pile():Liste()
{
	cout<<"\n Appel du constructeur de pile\n";
}
/*****************************************************************/

pile::~pile()
{
	cout<<"\n Appel du destructeur de pile\n";
}
/*****************************************************************/

void pile::empiler(void* x)
{
	int b=Liste::ajouter(1, x);
	if(b)
		Liste::longueur()++;
}
/*****************************************************************/

void* pile::depiler()
{
	void* a=Liste::ieme(1);
	int i=Liste::supprimer(1);
	if(i)
		return a;
}
/*****************************************************************/

void* pile::get_sommet()
{
	void *s=Liste::ieme(1);
	return s;
}
/*****************************************************************/

bool pile::est_vide()
{
	return (Liste::longueur()==0);
}
/*****************************************************************/

int pile::get_longueur()
{
	l=Liste::longueur();
	return l;
}
/*****************************************************************/
